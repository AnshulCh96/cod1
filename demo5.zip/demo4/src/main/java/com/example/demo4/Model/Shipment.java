package com.example.demo4.Model;

import java.util.Date;

public class Shipment {
    private String orderId;
    private  String shipmentId;
    private String productId;
    private Date shipmentDate;
    private  double qty;

    public Shipment(String orderId, String shipmentId, String productId, Date shipmentDate, double qty) {
        this.orderId = orderId;
        this.shipmentId = shipmentId;
        this.productId = productId;
        this.shipmentDate = shipmentDate;
        this.qty = qty;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getShipmentId() {
        return shipmentId;
    }

    public void setShipmentId(String shipmentId) {
        this.shipmentId = shipmentId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public Date getShipmentDate() {
        return shipmentDate;
    }

    public void setShipmentDate(Date shipmentDate) {
        this.shipmentDate = shipmentDate;
    }

    public double getQty() {
        return qty;
    }

    public void setQty(double qty) {
        this.qty = qty;
    }
}
