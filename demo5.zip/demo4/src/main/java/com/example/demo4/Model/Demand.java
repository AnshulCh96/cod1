package com.example.demo4.Model;

public class Demand {
    private  String productid;
    private  Double quantity;

    public String getProductid() {
        return productid;
    }

    public void setProductid(String productid) {
        this.productid = productid;
    }

    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    public Demand(String productid, Double quantity) {
        this.productid = productid;
        this.quantity=quantity;
    }
}
