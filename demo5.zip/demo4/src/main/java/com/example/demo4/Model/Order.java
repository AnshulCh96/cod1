package com.example.demo4.Model;

public class Order {
    private String orderId;
    private String productId;
    private  double qty;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public double getQty() {
        return qty;
    }

    public void setQty(double qty) {
        this.qty = qty;
    }

    public Order(String orderId, String productId, double qty) {
        this.orderId = orderId;
        this.productId = productId;
        this.qty = qty;
    }
}
