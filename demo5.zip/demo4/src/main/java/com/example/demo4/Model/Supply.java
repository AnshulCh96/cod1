package com.example.demo4.Model;

public class Supply {
    private String productId;
    private double quantity;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public Supply(String productId,Double quantity) {
        this.productId = productId;
        this.quantity=quantity;
    }

}
