package com.example.demo4.Controller;

import com.example.demo4.Model.AvailabiltyResponse;
import com.example.demo4.Service.DemoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController
{
    @Autowired
    private DemoService demoService;
    @GetMapping("/getAvailability")
    public ResponseEntity<AvailabiltyResponse> getAvailability(@RequestParam String productID){
        AvailabiltyResponse availabiltyResponse =demoService.getAvailability(productID);
        if (availabiltyResponse!=null){
            return new ResponseEntity<>(availabiltyResponse, HttpStatus.OK);
        }
        else
            return  new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
