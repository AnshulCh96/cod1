package com.example.demo4.Model;

public class AvailabiltyResponse {
    private  String productId;
    private double availability;

    public AvailabiltyResponse(String productId, Double availability) {
        this.productId = productId;
        this.availability=availability;

    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public double getAvailability() {
        return availability;
    }

    public void setAvailability(double availability) {
        this.availability = availability;
    }
}
