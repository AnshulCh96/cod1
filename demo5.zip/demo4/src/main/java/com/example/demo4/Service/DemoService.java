package com.example.demo4.Service;

import com.example.demo4.Model.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

@Service
public class DemoService {
    private List<Supply> supplyList= new ArrayList<>();

    private  List<Demand>demandList= new ArrayList<>();

    public DemoService(){
        supplyList.add(new Supply("Product1",10.0));
        supplyList.add(new Supply("Product2",5.0));

        demandList.add(new Demand("Product1",2.0));
        demandList.add(new Demand("Product2",5.0));


    }
    public AvailabiltyResponse getAvailability(String productId){
        double supplyQuantity = supplyList.stream().filter(supply->supply.getProductId().equals(productId))
                .mapToDouble(Supply::getQuantity).sum();

        double demandQuantity= demandList.stream().filter(demand->demand.getProductid().equals(productId))
                .mapToDouble(Demand::getQuantity).sum();

        double availabilty = supplyQuantity-demandQuantity;

        if (availabilty>0){
            return  new AvailabiltyResponse(productId,availabilty);

        }
        else
            return  null; // return null to indicate 204 no content
    }
    //Order Shipment Logic
//    public CompletableFuture<Order> getOderDetails(String orderId){
//        return CompletableFuture.supplyAsync(()->new Order("Order1","Prod1",2.0));
//
//    }
//    public CompletableFuture<Shipment> getShipmentDetails(String orderId){
//        return CompletableFuture.supplyAsync(()->new Shipment());
//
//    }

}
